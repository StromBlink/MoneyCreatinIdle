#import <Foundation/Foundation.h>
#import <CoreHaptics/CoreHaptics.h>
#import "UnityInterface.h"

typedef void (*HapticCallback)();
