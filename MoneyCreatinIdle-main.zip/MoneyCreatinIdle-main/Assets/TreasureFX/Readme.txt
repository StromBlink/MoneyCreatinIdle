---------------
TREASURE FX
---------------
To use the effects, simply find a way to instantiate them, or drag & drop them into the scene.

The effects will automatically start playing when the build is running.

---------------
SCALING EFFECTS
---------------

To scale an effect in the scene, simply use the default Scaling tool (Hotkey 'R'). You can also select the effect and type in the Scale in Transform manually.

---------------
URP UPGRADE
---------------

If you want to upgrade the asset to URP, find the 'Treasure FX/Upgrade' folder and doubleclick the 'Treasure FX URP (2019.4 LTS)' unitypackage, then import it to your project.

---------------
CONTACT
---------------

Twitter: @archanor
Support: archanor.com/support.html

Follow me and my work on Twitter for updates and new VFX assets.

Ratings & reviews are much appreciated!

---------------

Made by Kenneth "Archanor" Foldal Moe
